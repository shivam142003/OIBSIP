# Oasis Infobyte Web Development and Designing Internship
Hello Everyone Completed My Level 2 Tasks under Oasis Infobyte Web Development and Designing Internship 

Task 1 - Calculator**
	Language- HTML,CSS,Javascript
	IDE- VS Code
Task 2 - Tribute Page**
	Language- HTML, CSS
	IDE- VS Code
Task 3 - To-Do App**
	Language- HTML, CSS, Javascript
	IDE- VS Code

